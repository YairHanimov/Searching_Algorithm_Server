//
// Created by eyal on 16.1.2020.
//

#ifndef SEARCHING_ALGORITHM_SERVER_BFS_H
#define SEARCHING_ALGORITHM_SERVER_BFS_H

#include "Searcher.h"
#include <list>
using namespace std;

template<class T>
class BFS : public Searcher<T>{
public:
   
};


#endif //SEARCHING_ALGORITHM_SERVER_BFS_H
